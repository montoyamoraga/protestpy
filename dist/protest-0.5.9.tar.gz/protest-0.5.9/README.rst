protest.py
==========

python module by aarón montoya-moraga, first released on march 2017.
it is a part of "its-ok", his graduate thesis at nyu itp.

installation
------------

install with pip:

  pip install protest

special thanks
--------------

allison parrish, andrew lazarow, justin peake, lauren mccarthy, sam lavigne, tigran paravyan, wipawe sirikolkarn, yuan gao, yuli cai, zoe bachman

license
-------

mit
