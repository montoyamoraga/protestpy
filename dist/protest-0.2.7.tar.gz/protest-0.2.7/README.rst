protest.py
==========

python module written by aaron montoya-moraga, march 2017, part of "it's okay", his graduation thesis at nyu itp.

installation
------------

install with pip:

  pip install protest

special thanks
--------------

allison parrish, andrew lazarow, justin peake, lauren mccarthy, sam lavigne, tigran paravyan, wipawe sirikolkarn, yuan gao, yuli cai, zoe bachman
