protest.py
==========

python module by aarón montoya-moraga, first released on march 2017.
it is a part of "its-ok", his graduate thesis at nyu itp.

installation
------------

install with pip:

  pip install protest

examples
--------

these are some examples of protest.py being used for protesting against trees.

.. image::  https://raw.githubusercontent.com/montoyamoraga/protestpy/gh-pages/example-trees/1.png

.. image::  https://raw.githubusercontent.com/montoyamoraga/protestpy/gh-pages/example-trees/8.png

.. image::  https://raw.githubusercontent.com/montoyamoraga/protestpy/gh-pages/example-trees/44.png

special thanks
--------------

allison parrish, andrew lazarow, justin peake, lauren mccarthy, sam lavigne, tigran paravyan, wipawe sirikolkarn, yuan gao, yuli cai, zoe bachman

license
-------

mit
